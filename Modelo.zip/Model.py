from keras import backend as K
import tensorflow as tf
import numpy as np
from pre_processing import preprocess_dataset


def root_mean_squared_error(y_true, y_pred):
    return K.sqrt(K.mean(K.square(y_pred - y_true)))


def load_model(model_folder):
    new_model = tf.keras.models.load_model(model_folder, custom_objects={'root_mean_squared_error':root_mean_squared_error})
    return new_model


def evaluate_folder(model, test_path):
    test_file_names = tf.io.gfile.glob(str(test_path) + '/*')
    test_ds = preprocess_dataset(test_file_names)
    IMC = []
    for i, (audio, label) in enumerate(test_ds):
        IMC.append(model.predict(audio)[0][0])
    return IMC

def evaluate_file(model, file_path):
    test_file = tf.constant(file_path, dtype=tf.string)
    test_ds = preprocess_dataset([test_file])
    for audio, label in test_ds:
        IMC = model.predict(audio)[0][0]
    return IMC


"""

model_path = r'D:\U\Feria 2021-2\Modelo\Model'
test_folder_path = r'D:\U\Feria 2021-2\Modelo\TEST'
test_file_path = r'D:\U\Feria 2021-2\Modelo\TEST\Copia de Hin_0004_Hin_m_0019#25.051652892561982#.wav'

model = load_model(model_path)
print(evaluate_folder(model, test_folder_path))
print(evaluate_file(model, test_file_path))

"""